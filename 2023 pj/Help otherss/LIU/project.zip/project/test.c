#include<stdio.h>
#include<time.h>
#include<math.h>
int main(){
    printf("hello world");
}